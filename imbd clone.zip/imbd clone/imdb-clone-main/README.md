# imdb-clone

in this project i tried to replecate the features of imdb
which is for front end skill test in coding ninjas

in this project we can
  1. search movies
  2. view details of particular movie
  3. add / remove movie from favourite section
  
by default it shows tending movies on home pages


i have used basic skill set for this project such as
  1. html 5
  2. css 3
  3. javascript

to fetch movie details i have used api from "the movie database" (tmdb)
-> https://developers.themoviedb.org/3/getting-started/introduction
